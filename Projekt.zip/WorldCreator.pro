TEMPLATE = app
CONFIG += console c++11
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += \
    World.cpp \
    Visualizing.cpp \
    Main.cpp \
    Interface.cpp

HEADERS += \
    World.h \
    Visualizing.h \
    Interface.h
